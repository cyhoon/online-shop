import PostalForm from './PostalForm';
export default PostalForm;