import React from 'react';
import styled from 'styled-components';

const ProductType = () => {
    const Container = styled.div`
        width: 300px;
        height: 200px;
        margin-left: 10px;
        margin-right: 10px;
        border: 1px solid black;
        position: relative;
    `;

    const VisualContainer = styled.div`
        width: 200px;
        height: 80px;
        background-color: #eee;
        border: 1px solid black;
        position: relative;
        top: -10px;
    `;

    const ExperienceContainer = styled.div`
        width: 100%;
    `;

    return (
        <Container>
            
        </Container>
    );
};

export default ProductType;