import TypeItem from './TypeItem';
export default TypeItem;