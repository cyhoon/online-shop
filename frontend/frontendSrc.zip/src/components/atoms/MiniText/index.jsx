import MiniText from './MiniText';
export default MiniText;