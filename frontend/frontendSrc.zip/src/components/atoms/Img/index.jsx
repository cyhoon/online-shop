import Img from './Img';
export default Img;