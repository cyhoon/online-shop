import Jumbotron from './Jumbotron';
export default Jumbotron;