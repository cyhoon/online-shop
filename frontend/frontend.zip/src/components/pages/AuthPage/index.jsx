import AuthPage from './AuthPage';
export default AuthPage;