import React from 'react';
import CategoryTemplate from '../../templates/CategoryTemplate';

const CategoryPage = () => {
    return (
        <CategoryTemplate 
            
        />
    );
};

export default CategoryPage;