import React from 'react';
import ProductTemplate from '../../templates/ProductTemplate';

const ProductPage = () => {
    return (
        <ProductTemplate
            
        />
    );
};

export default ProductPage;