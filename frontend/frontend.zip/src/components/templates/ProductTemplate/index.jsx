import ProductTemplate from './ProductTemplate';
export default ProductTemplate;