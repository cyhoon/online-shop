import AuthTemplate from './AuthTemplate';
export default AuthTemplate;