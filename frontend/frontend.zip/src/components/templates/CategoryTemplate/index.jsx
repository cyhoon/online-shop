import CategoryTemplate from './CategoryTemplate';
export default CategoryTemplate;