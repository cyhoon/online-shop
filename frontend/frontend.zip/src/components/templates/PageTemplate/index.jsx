import PageTemplate from './PageTemplate';
export default PageTemplate;