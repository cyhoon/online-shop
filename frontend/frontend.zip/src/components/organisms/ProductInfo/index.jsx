import ProductInfo from './ProductInfo';
export default ProductInfo;