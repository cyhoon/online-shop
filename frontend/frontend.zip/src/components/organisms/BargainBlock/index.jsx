import BargainBlock from './BargainBlock';
export default BargainBlock;