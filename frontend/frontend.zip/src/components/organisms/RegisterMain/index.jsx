import RegisterMain from './RegisterMain';
export default RegisterMain;