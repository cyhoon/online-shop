import RegisterForm from './RegisterForm';
export default RegisterForm;