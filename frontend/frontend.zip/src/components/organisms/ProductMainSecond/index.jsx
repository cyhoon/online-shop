import ProductMainSecond from './ProductMainSecond';
export default ProductMainSecond;