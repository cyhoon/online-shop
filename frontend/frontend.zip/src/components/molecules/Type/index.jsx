import Type from './Type';
export default Type;