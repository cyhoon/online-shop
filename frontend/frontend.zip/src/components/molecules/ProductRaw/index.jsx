import ProductRaw from './ProductRaw';
export default ProductRaw;