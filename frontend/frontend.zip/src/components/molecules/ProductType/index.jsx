import ProductType from './ProductType';
export default ProductType;