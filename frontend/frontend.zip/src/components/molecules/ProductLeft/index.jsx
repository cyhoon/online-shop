import ProductLeft from './ProductLeft';
export default ProductLeft;