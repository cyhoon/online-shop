import Information from './Information';
export default Information;