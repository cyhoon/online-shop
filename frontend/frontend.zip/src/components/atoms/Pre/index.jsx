import Pre from './Pre';
export default Pre;